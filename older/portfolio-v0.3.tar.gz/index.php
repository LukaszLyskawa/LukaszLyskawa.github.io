<?php include 'php/strings.php';?>
<!DOCTYPE html>
<html>
    <head>
        <?php include 'php/header.php'; ?>
    </head>
    <body>
        <?php include 'php/menu.php';?>
        <div class="content" id="content">
            <?php include 'Projekty.php'; ?>
        </div>
        <?php include 'php/footer.php'; ?>
    </body>
</html>
