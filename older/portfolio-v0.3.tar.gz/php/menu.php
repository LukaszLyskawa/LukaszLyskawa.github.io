<div class="navbar-fixed-top container-fluid header noselect" style="background-color: #fff">
    <ul class="nav navbar-nav navbar-collapse collapse">
        <li><a href="https://pl.linkedin.com/in/łukasz-łyskawa-569021b3"><img width="20px" height="20px" class="img-responsive" src="img/LinkedIn-Google-Plus-Profile-Pic-01.png"></a></li>
        <li><a href="/"><img  height="20px" src="img/cv-pdf.png"></a></li>
        <li><a href="/"><img  height="20px" src="img/cv-doc.png"></a></li>
        <li><a href="https://github.com/LukaszLyskawa"><img width="20px" height="20px" src="img/GitHub-Mark.png"></a></li>
    </ul>
    <ul class="nav navbar-nav navbar-right navbar-collapse collapse">
        <li><a href="mailto:lukasz@lyskawa.pl">lukasz@lyskawa.pl</a></li>
        <li class="navbar-text">tel. 607-111-103</li>
    </ul>
</div>
<nav class="navbar navbar-fixed-top navbar-default noselect">
    <div class="container">

        <div class="navbar-header">
            <div class="navbar-brand">
                Łukasz Łyskawa
                <div class="navbar-collapse collapse">C# programmer</div>
            </div>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
        </div>

      <div id="navbar" class="collapse navbar-collapse navbar-right">
        <ul class="nav navbar-nav">
            <li><a class="sliding-middle-out active" onmouseup="changeContent('Projekty')">Projekty</a></li>
          <li><a class="sliding-middle-out" onmouseup="changeContent('Certyfikaty')">Certyfikaty</a></li>
          <li><a class="sliding-middle-out" onmouseup="changeContent('Kontakt')">Kontakt</a></li>
        </ul>
      </div>
  </div>
</nav>