<?php
$Lorem = "Lorem ipsum dolor sit amet, "
        . "orci at ante lorem sed metus. "
        . "aucibus ad, viverra ridiculus vestibulum adipiscing, enim malesuada vel ipsum nec, "
        . "ipsum potenti, phasellus vestibulum adipiscing vivamus. Est mauris congue. Mollis cursus metus felis pulvinar, "
        . "vel parturient facilisi feugiat nullam wisi ligula, duis libero erat habitasse, tortor nec, tempus ac eu fusce. Turpis ridiculus diam, "
        . "sed cum quisque suspendisse, mattis ipsum, eget in id vehicula nulla consectetuer in."
?>