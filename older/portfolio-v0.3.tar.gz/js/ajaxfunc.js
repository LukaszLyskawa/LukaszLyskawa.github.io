function changeContent(file){
    if (file == "") {
        document.getElementById("content").innerHTML = "";
        return;
    } else { 
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("content").innerHTML = xmlhttp.responseText;
                $('pre code').each(function(i, block) {
                    hljs.highlightBlock(block);
                });
                $("html").getNiceScroll().resize();
            }
        };
        switch(file)
        {
            case "Projekty":
                xmlhttp.open("GET","Projekty.php",true);
                break;
            case "Certyfikaty":
                xmlhttp.open("GET","Certyfikaty.php",true);
                break;
            case "Kontakt":
                xmlhttp.open("GET","Kontakt.php",true);
                break;
        }
        
        xmlhttp.send();
        

    }
}


