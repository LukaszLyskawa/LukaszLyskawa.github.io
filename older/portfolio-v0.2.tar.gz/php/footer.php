<script type="text/javascript">
    $('#navbar ul li a').click(function (e) {
        $('.active').removeClass('active').addClass('sliding-middle-out');
        var $this = $(this);
        if(!$this.hasClass('active'))
        {
            $this.addClass('active');
            $this.removeClass('sliding-middle-out');
        }
        e.preventDefault();
    });
    $(document).ready(function(){
        $("html").niceScroll({zindex:9999, autohidemode:false, cursorwidth:10});
    });
</script>
