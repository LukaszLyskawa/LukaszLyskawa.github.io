<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Łukasz Łyskawa - Portfolio</title>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" href="../css/bootstrap-theme.css">
<link rel="stylesheet" href="../css/myTemplate.css">
<link rel="stylesheet" href="../css/SyntaxHighlighter.css">

<script src="../js/jquery-1.11.3.min.js"></script>
<script src="../js/jquery.nicescroll.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/ajaxfunc.js"></script>
<link href='//cdnjs.cloudflare.com/ajax/libs/highlight.js/8.6/styles/vs.min.css' rel='stylesheet'/>
<script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.0.0/highlight.min.js"></script>
<script>$(document).ready(function() {
  $('pre code').each(function(i, block) {
    hljs.highlightBlock(block);
  });
});</script>
