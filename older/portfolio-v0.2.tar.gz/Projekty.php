<?php
    include 'php/strings.php';
    include 'php/footer.php';
?>
<div class="jumbotron">
    <h1>Team Randomizer</h1>
</div>
<div class="container-fluid">
    <div class="row">
        <h3>Technologie:</h3>
        <h2>
            <ul class="list-inline">
                <li>C#</li>
                <li>WPF</li>
                <li>MVVM</li>
            </ul>
        </h2>
    </div>
    <div class="row" style="padding: 10px;">
        <div class="col-md-6" style="padding: 10px;"><?php echo $Lorem?><?php echo $Lorem?></div>
        <div class="col-md-6" style="padding: 10px;"><img class="img-responsive center-block" style="max-height: 400px;" src="img/placeholder.jpg"></div>
        <div class="col-md-8 col-md-offset-2" style="text-align: left; padding: 10px;">
            <pre>
<code class="c#" style="max-height: 500px;">
    
    public static class Complex
    {
        private static IEnumerable<GroupSetting> _groups;
        private static IEnumerable<SummonerData> _summonerData;
        public async static Task<IEnumerable<SummonerData>> Shuffle(
            IEnumerable<SummonerData> Summoners, 
            IEnumerable<GroupSetting> Groups, TimeSpan timeout)
        {
            _summonerData = Summoners;
            _groups = Groups;
            Summoners = (await Simple.ShuffleListAsync(Summoners, timeout))
                                     .OfType<SummonerData>()
                                     .ToList();
            return CreateTeams(DivideSummoner(Summoners));
        }

        private static IEnumerable<SummonerData> CreateTeams(List<List<SummonerData>> SummonerGroups)
        {
            var resultlist = new List<SummonerData>();
            
            while (resultlist.Count < _summonerData.Count())
            {
                var iteration = 0;
                foreach (var group in _groups)
                {
                    for (var i = 0; i < group.Number; i++)
                    {
                        if (SummonerGroups[iteration].Any())
                        {
                            resultlist.Add(SummonerGroups[iteration].First());
                            SummonerGroups[iteration].Remove(SummonerGroups[iteration].First());
                        }
                    }
                    iteration++;
                }
            }

            return resultlist;
        }
        private static List<List<SummonerData>> DivideSummoner(IEnumerable<SummonerData> Summoners)
        {
            var resultList = new List<List<SummonerData>>();
            var i = 0;

            foreach (var group in _groups)
            {
                resultList.Add(new List<SummonerData>());
                foreach (var summoner in Summoners)
                {
                    if (summoner.Division >= group.From && summoner.Division <= group.To)
                        resultList[i].Add(summoner);
                }
                i++;
            }
            return resultList;

        }
    }
    
</code>
</pre></div>
    </div>
</div>

    



